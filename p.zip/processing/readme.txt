1. Extrae todo el contenido de p.zip al directorio que quieras.
2. Haz cd al directorio processing. Este directorio debe contener lib, src, y este readme.txt.
3. Para compilar:
     javac -classpath lib/core.jar -d build src/aplicacion/Main.java
4. Para ejecutar:
     java -classpath build:lib/core.jar aplicacion.Main
